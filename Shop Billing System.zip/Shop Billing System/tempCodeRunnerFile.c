#include<iostream.h>
#include<stdio.h>
#include<conio.h>

//int Solution::solve(int A, int B) 
int main()
{
int a[80];
int n;
int i;
cout<<"Enter the number of array"<<endl;
for (i=0;i<n;i++)
{       
cin>>a[i];
}
return 0;
}